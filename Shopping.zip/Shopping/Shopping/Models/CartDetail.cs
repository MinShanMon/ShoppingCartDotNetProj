﻿using System;
namespace Shopping.Models
{
    public class CartDetail
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
