﻿using System.Numerics;

public class PurchasedActivation
{
    public Guid ActivationCode { get; set; }
    public int ProductId { get; set; }
    public string TimeStamp { get; set; }

}